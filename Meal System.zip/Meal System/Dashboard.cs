﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Meal_System
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        public Dashboard(String user)
        {
            InitializeComponent();

            if (user == "Admin")
            {
                //btnSearch.Hide();
                btnAdd.Show();
                btnUpdate.Show();
                btnDelete.Show();
                txtMealItem.Show();
                txtPrice.Show();
                lblMealItem.Show();
                lblPrice.Show();
            }
            else if (user == "Student")
            {
                btnSearch.Show();
                btnAdd.Hide();
                btnUpdate.Hide();
                btnDelete.Hide();
                txtMealItem.Hide();
                txtPrice.Hide();
                lblMealItem.Hide();
                lblPrice.Hide();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\Desktop\\Meal System\\MealSystemDB.mdf\";Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ItemTable values (@Day,@Meal_Type,@Meal_Item,@Price)", con);
            cmd.Parameters.AddWithValue("@Day", txtDay.Text);
            cmd.Parameters.AddWithValue("@Meal_Type", txtMealType.Text);
            cmd.Parameters.AddWithValue("@Meal_Item", txtMealItem.Text);
            cmd.Parameters.AddWithValue("@Price", int.Parse(txtPrice.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Added Successfully.");
            clearAll();
        }

        private void btnLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login fm = new Login();
            this.Hide();
            fm.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\Desktop\\Meal System\\MealSystemDB.mdf\";Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("update ItemTable set Meal_Item=@Meal_Item, Price=@Price where Day=@Day and Meal_Type=@Meal_Type", con);
            cmd.Parameters.AddWithValue("@Day", txtDay.Text);
            cmd.Parameters.AddWithValue("@Meal_Type", txtMealType.Text);
            cmd.Parameters.AddWithValue("@Meal_Item", txtMealItem.Text);
            cmd.Parameters.AddWithValue("@Price", int.Parse(txtPrice.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Updated Successfully.");
            clearAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\Desktop\\Meal System\\MealSystemDB.mdf\";Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete ItemTable where Day=@Day and Meal_Type=@Meal_Type", con);
            cmd.Parameters.AddWithValue("@Day", txtDay.Text);
            cmd.Parameters.AddWithValue("@Meal_Type", txtMealType.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Deleted Successfully.");
            clearAll();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Ashik\\Desktop\\Meal System\\MealSystemDB.mdf\";Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from ItemTable where Day=@Day and Meal_Type=@Meal_Type", con);
            cmd.Parameters.AddWithValue("@Day", txtDay.Text);
            cmd.Parameters.AddWithValue("@Meal_Type", txtMealType.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            clearAll();
        }
        public void clearAll()
        {
            txtDay.SelectedIndex = -1;
            txtMealType.SelectedIndex = -1;
            txtMealItem.Clear();
            txtPrice.Clear();
        }
    }
}
