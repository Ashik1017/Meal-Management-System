﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Meal_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserID.Text == "5102023" && txtPassword.Text == "Admin247")
            {
                Dashboard ds = new Dashboard("Admin");
                this.Hide();
                ds.Show();
            }
            else if (txtUserID.Text == "1111017" && txtPassword.Text == "Ashik017")
            {
                Dashboard ds = new Dashboard("Student");
                this.Hide();
                ds.Show();
            }
            else
            {
                MessageBox.Show("Incorrect User ID or Password.");
                clearAll();
            }
        }
        public void clearAll()
        {
            txtUserID.Clear();
            txtPassword.Clear();
        }
    }
}
